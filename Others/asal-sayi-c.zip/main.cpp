/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int main()
{
    int sayi;
    int i;
    int control=2;
    
do  {
    cout<<"Pozitif bir tam sayi girisi yapiniz:";
    cin>>sayi;
    
    for(i=2;i<sayi;i++) {
        if (sayi%i==0) {
            control=1;
        }
    }
    if(control==1) {
        cout<<"asal sayi degildir \n";
        control=2;
    }
    else {cout<<"asal sayidir \n";}
    
    }
while (sayi!=1);
    return 0;
}