/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int sayi;
    int bolum_1;
    int bolum_2;
    int bolum_3;
    int bolum_4;
    
    printf("4 basanakli bir sayi giriniz :");
    scanf("%d",&sayi);

    bolum_1 = sayi/1000;
    bolum_2 = (sayi%1000)/100;
    bolum_3 = ((sayi%1000)%100)/10;
    bolum_4 = ((sayi%1000)%100)%10;
    
    int rakamlar_toplami = bolum_1+bolum_2+bolum_3+bolum_4;
    
    printf("Rakamlar toplami :%d",rakamlar_toplami);
return 0; }