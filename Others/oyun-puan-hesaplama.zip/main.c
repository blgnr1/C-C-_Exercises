/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    
  int skor;
  int mac_sonucu;
  
  
  printf("Skoru giriniz :");
  scanf("%d",&skor);
  
  
  printf("Mac sonucunu giriniz :");
  scanf("%d",&mac_sonucu);
  
  
    if (mac_sonucu==1) {
        printf("Skor :%d\n",skor+20);
        printf("Puan degisimi :+20");
    }
    else if (mac_sonucu==-1) {
        printf("Skor :%d\n",skor-15);
        printf("Puan degisimi :-15");
    }
    else if (mac_sonucu==0) {
        if (skor>20) {
            printf ("Skor :%d\n",skor+5);
            printf ("Puan degisimi :+5");
        }
        else {
            printf ("Skor :%d\n",skor);
            printf ("Puan degisimi :0");
        }
    
    }
    else 
    printf("Lutfen 1,0,-1 degerlerinden bir tanesini girin");
  
  
    return 0;
}