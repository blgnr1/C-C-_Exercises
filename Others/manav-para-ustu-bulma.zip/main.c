/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
  int maliyet = 17;
  int odenen_para;
  
  printf("Odenen para miktarini giriniz :");
  scanf("%d",&odenen_para);
  if (odenen_para<0) {
      printf("Gecerli bir para miktari giriniz");
      return 0;
  }
  
  int para_ustu = odenen_para-maliyet;
  
  if (odenen_para<17) {
      printf("%d tl daha odemeniz gerekiyor", maliyet-odenen_para);
  }
  else if (odenen_para==17) {
      printf("Satin alma islemi tamamlandi");
  }
  else if (odenen_para>17) {
      printf("%d tl para ustu verilecek", odenen_para-maliyet);
  }

    return 0;
}