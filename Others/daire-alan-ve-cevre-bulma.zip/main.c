#include <stdio.h>
#include <stdlib.h>

int main () {
    float yaricap;
    printf("Yaricap degeri girin :", yaricap);
    scanf("%f",&yaricap);

    float dairenin_alani;
    dairenin_alani = yaricap*yaricap*3.14;
    
    float dairenin_cevresi;
    dairenin_cevresi = yaricap*2*3.14;

    printf("Dairenin alani :%f\n", dairenin_alani);
    printf("Dairenin cevresi :%f", dairenin_cevresi);

    return 0;

}