/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int alinan_kitap_sayisi ;
    float kazanilan_indirim_yuzdesi ;
    float birim_kitap_fiyati ;
    float toplam_ucret;
    float indirimli_ucret;
    
    printf("Kitabin fiyatini giriniz :");
    scanf("%f",&birim_kitap_fiyati);
    
    if (birim_kitap_fiyati <=0) {
        printf("Gecerli bir kitap fiyati giriniz");
        return 0;
    }
    
    printf ("Alinan kitap sayisini giriniz :");
    scanf("%d",&alinan_kitap_sayisi);
    
    if (alinan_kitap_sayisi<50 && alinan_kitap_sayisi >=0) {
        kazanilan_indirim_yuzdesi = 0;
        toplam_ucret = birim_kitap_fiyati*alinan_kitap_sayisi;
        indirimli_ucret = toplam_ucret-(toplam_ucret*kazanilan_indirim_yuzdesi/100);
        printf("Toplam ucret %f tl",indirimli_ucret);
    }
    else if (alinan_kitap_sayisi >=50 && alinan_kitap_sayisi <100) {
        kazanilan_indirim_yuzdesi = 10;
        toplam_ucret = birim_kitap_fiyati*alinan_kitap_sayisi;
        indirimli_ucret = toplam_ucret-(toplam_ucret*kazanilan_indirim_yuzdesi/100);
        printf("Toplam ucret %f tl",indirimli_ucret);
    }
    else if (alinan_kitap_sayisi >=100) {
        kazanilan_indirim_yuzdesi = 20;
        toplam_ucret = birim_kitap_fiyati*alinan_kitap_sayisi ;
        indirimli_ucret = toplam_ucret-(toplam_ucret*kazanilan_indirim_yuzdesi/100)  ;
        printf("Toplam ucret %f tl",indirimli_ucret);
    }
    else {
        printf("Gecerli bir kitap sayisi giriniz");
    }
        
    return 0;
}
