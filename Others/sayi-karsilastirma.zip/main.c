/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int num1;
    int num2;
    
    printf("Iki adet sayi giriniz :");
    scanf("%d %d",&num1,&num2);
    
    if (num1>num2) {
        printf("num1 buyuktur num2");
    }
    else if (num2>num1) {
        printf("num2 buyuktur num1");
    }
    else {
        printf("Iki sayi birbirine esittir");
    }

    return 0;
}