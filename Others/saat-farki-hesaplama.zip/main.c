/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    
 int saat_1, saat_2;
 int dakika_1, dakika_2;
 int saniye_1, saniye_2;
 
 
 printf("Saati girin :");
 scanf("%d",&saat_1);
 if (saat_1<0 || saat_1>=24) {
     printf("Saati hatali girdiniz");
     return 0;
 }
 
 printf("Dakikayi girin :");
 scanf("%d",&dakika_1);
 if (dakika_1<0 || dakika_1>=60) {
     printf("Dakikayi hatali girdiniz");
     return 0;
 }
 
 printf("Saniyeyi girin :");
 scanf("%d",&saniye_1);
 if (saniye_1<0) {
        printf("Saniyeyi hatali girdiniz");
        return 0;
 }
    
 printf("2.saati girin :");
 scanf("%d",&saat_2);
 if (saat_2<0 || saat_2>=24) {
     printf("Saati hatali girdiniz");
     return 0;
 }
 
 printf("2.dakikayi girin :");
 scanf("%d",&dakika_2); 
 if (dakika_2<0 || dakika_2>=60) {
     printf("Dakikayi hatali girdiniz");
     return 0;
 }
     
 printf("2.saniyeyi girin :");
 scanf("%d",&saniye_2);
 if (saniye_2<0) {
        printf("Saniyeyi hatali girdiniz");
        return 0;
}

 int zaman_1 = saat_1*3600+dakika_1*60+saniye_1;
 int zaman_2 = saat_2*3600+dakika_2*60+saniye_2;
 int fark = zaman_1-zaman_2;
 
 if (fark<0) {
     fark = -fark;
 }
     printf("Iki zaman dilimi arasindaki fark :%d saniye",fark);
     
    return 0;
}
