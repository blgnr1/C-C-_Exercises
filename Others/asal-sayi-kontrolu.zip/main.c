/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*sayi / 2 den  sayi/ sayi-1 e kadar hesapla
eger icinde int var ise sayi asal degil yok ise sayi asal*/

#include <stdio.h>

int main()
{
   int sayi;
   int bolen;
   int asal = 1;
   
   printf("Sayiyi giriniz :");
   scanf("%d",&sayi); 
      
   
   for (bolen=2; bolen <=sayi-1; bolen++) {
       if (sayi % bolen ==0) {
           asal = 0;
           break;
       }
   }
   
   if (asal == 1 && sayi>1) {
       printf("%d bir asal sayidir", sayi);
   }
   else {
       printf("%d bir asal sayi degildir", sayi);
   }

    return 0;
}