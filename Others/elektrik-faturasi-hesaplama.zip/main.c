/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
 float harcanan_Kwh;
 float Kwh_ucreti;
 float abonelik_ucreti;
 float aylik_enflasyon;
 float ucret;
 
printf("Harcanan Kwh degerini giriniz :");
scanf("%f",&harcanan_Kwh);
printf("Birim Kwh ucretini giriniz :");
scanf("%f",&Kwh_ucreti);
printf("Abonelik ucretini giriniz :");
scanf("%f",&abonelik_ucreti);
printf("Aylik enflasyon miktarini giriniz :");
scanf("%f",&aylik_enflasyon);

 float zamli_Kwh_ucreti;
 float zamli_abonelik_ucreti;
 
 zamli_abonelik_ucreti = abonelik_ucreti+(abonelik_ucreti*aylik_enflasyon/100);
 zamli_Kwh_ucreti = Kwh_ucreti+(Kwh_ucreti*aylik_enflasyon/100);
 
 ucret = zamli_abonelik_ucreti+(zamli_Kwh_ucreti*harcanan_Kwh);
 
 printf("Ucret %.3f tldir",ucret);
 

    return 0;
}
